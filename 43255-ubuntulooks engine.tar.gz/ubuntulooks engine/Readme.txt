====================
Ubuntulooks Engine
Packaged by Viper550
====================

======
Includes
======
- Ubuntulooks GTK2 Engine and Theme


=============================
Ubuntulooks Engine Installation Instructions
=============================
Step 1.
Copy libubuntulooks.so and libubuntulooks.la to /usr/lib/gtk-2.0/2.*.*/engines as root (substitute "2.*.*" with your version number)

Step 2.
Copy the Human folder to /usr/share/themes/ as root (or to ~/.themes , but it will only be on your account)

Step 3.
Go into your Gnome Theme Prefrences and select Human (or any other Ubuntulooks enabled GTK theme, Human is just included as an example) as your theme under Controls and Window Border. The metacity theme used on Human is a modified version of ClearLooks 2.0 if you wonder, but any other will do too!


===============
System Requirements
===============
Simple:
Requires a GTK version with support for Cairo rendering, or if you can do ClearLooks 2/CVS or other Cairo engines like Murrine, you can use this theme.
